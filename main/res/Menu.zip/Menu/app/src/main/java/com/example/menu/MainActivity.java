package com.example.menu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    EditText goldWeight, CGoldValue;
    RadioGroup radioGroup;
    Button btnCalc, btnClr;
    TextView outputTGV, outputZP, outputTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        goldWeight = (EditText) findViewById(R.id.goldWeight);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        CGoldValue = (EditText) findViewById(R.id.CGoldValue);
        btnCalc = (Button) findViewById(R.id.btnCalc);
        btnClr = (Button) findViewById(R.id.btnClr);
        outputTGV = (TextView) findViewById(R.id.outputTGV);
        outputZP = (TextView) findViewById(R.id.outputZP);
        outputTotal = (TextView) findViewById(R.id.outputTotal);

        btnCalc.setOnClickListener(this);
        btnClr.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        int checkedId = radioGroup.getCheckedRadioButtonId();
        if(view.getId() == btnCalc.getId()){
            try {

                switch (view.getId()){
                    case R.id.btnCalc:

                        int value = 0;
                        if(checkedId==-1){
                            //no radio buttons are selected
                            Toast.makeText(MainActivity.this, "Please select type of gold!", Toast.LENGTH_SHORT).show();
                        }else {


                            switch (checkedId) {
                                case R.id.keepRB:
                                    value = 85;

                                    break;

                                case R.id.wearRB:
                                    value = 200;

                                    break;
                            }
                        }

                        double weight = Double.parseDouble(goldWeight.getText().toString());
                        double gValue = Double.parseDouble(CGoldValue.getText().toString());
                        double totalGV = weight * gValue;
                        outputTGV.setText(String.format( "RM %.2f", totalGV));

                        double uruf = weight - value;
                        double totalZP = 0;
                        if(uruf < 0){
                            totalZP = 0;
                        }else{
                            totalZP = uruf * gValue;
                        }
                        outputZP.setText(String.format( "RM %.2f", totalZP));

                        double finalTotal = 0.025 * totalZP;
                        outputTotal.setText(String.format( "RM %.2f", finalTotal));

                        break;
                }

            }catch(NumberFormatException nfe) {
                Toast.makeText(this, "Please enter the value!", Toast.LENGTH_SHORT).show();
            }
        }
        else if(view.getId() == btnClr.getId()){
            goldWeight.setText(" ");
            CGoldValue.setText(" ");
            outputTGV.setText(" ");
            outputZP.setText(" ");
            outputTotal.setText(" ");
            radioGroup.clearCheck();
        }
    }
}