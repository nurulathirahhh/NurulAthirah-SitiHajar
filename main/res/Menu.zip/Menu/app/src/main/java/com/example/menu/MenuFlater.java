package com.example.menu;

public class MenuFlater {
}
